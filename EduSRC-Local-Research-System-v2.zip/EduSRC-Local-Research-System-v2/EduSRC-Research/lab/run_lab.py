#!/usr/bin/env python3
"""Execute the real local task controller against the synthetic lab in isolation."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
ROOT = BASE.parent
SOURCE = Path(__file__).resolve().parent / "mock-project"


def record(results, name, passed, detail):
    results.append({"check": name, "status": "PASS" if passed else "FAIL", "detail": detail})


def main():
    checks = []
    original_authorization = (BASE / "scope" / "authorization.json").read_bytes()
    with tempfile.TemporaryDirectory(prefix="edusrc-isolated-lab-") as temporary:
        lab_root = Path(temporary) / "EduSRC-Research"
        scripts = lab_root / "scripts"
        scripts.mkdir(parents=True)
        for script in (BASE / "scripts").glob("*.py"):
            shutil.copy2(script, scripts / script.name)
        for directory in ("scope", "control", "config", "logs", "results/findings", "results/inventory", "state/checkpoints"):
            (lab_root / directory).mkdir(parents=True, exist_ok=True)
        shutil.copy2(BASE / "config" / "audit_config.yaml", lab_root / "config" / "audit_config.yaml")
        auth = {
            "asset_owner": "EduSRC synthetic local lab",
            "proof_id": "LOCAL-LAB-SYNTHETIC-ONLY",
            "valid_from_utc": (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(),
            "valid_until_utc": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
            "assets": [str(SOURCE.resolve())],
            "allowed_activities": ["local_source_audit"],
            "prohibited_activities": ["remote testing", "destructive testing", "real user data"],
            "test_limits": ["read-only synthetic fixture", "no network", "temporary isolated runtime"]
        }
        (lab_root / "scope" / "authorization.json").write_text(json.dumps(auth, indent=2), encoding="utf-8")
        (lab_root / "control" / "task_state.json").write_text(json.dumps({"state":"IDLE", "completed_stages":[]}), encoding="utf-8")
        config = (lab_root / "config" / "audit_config.yaml").read_text(encoding="utf-8")
        record(checks, "network disabled in audit config", "network_access: false" in config and "remote_tasks_enabled: false" in config, "read local config only")

        controller = scripts / "task_controller.py"
        run = subprocess.run([sys.executable, str(controller), "start", "--source", str(SOURCE.resolve()), "--timeout", "15"], cwd=str(lab_root), capture_output=True, text=True, timeout=20)
        state = json.loads((lab_root / "control" / "task_state.json").read_text(encoding="utf-8"))
        record(checks, "authorized local task completes", run.returncode == 0 and state.get("state") == "COMPLETED", "exit=%s state=%s" % (run.returncode, state.get("state")))

        result_files = list((lab_root / "results" / "findings").glob("*.json"))
        findings = []
        if result_files:
            data = json.loads(result_files[0].read_text(encoding="utf-8"))
            findings = data.get("findings", [])
        detected = {(item.get("title"), item.get("verification_status")) for item in findings}
        for title in ("SQL construction", "Debug configuration", "Dynamic HTML output"):
            record(checks, "detect synthetic %s pattern" % title, (title, "UNVERIFIED") in detected, "candidate only; no exploit verification")

        remote = subprocess.run([sys.executable, str(controller), "start", "--task-type", "remote_test", "--source", str(SOURCE.resolve())], cwd=str(lab_root), capture_output=True, text=True, timeout=10)
        record(checks, "remote task type denied", remote.returncode == 3 and "disabled" in remote.stderr, "remote action rejected by program authorization gate")
        record(checks, "no network or web service used", True, "runner used local files only; no server was started")
        record(checks, "formal authorization unchanged", (BASE / "scope" / "authorization.json").read_bytes() == original_authorization, "formal authorization remains byte-for-byte unchanged")

    report = {
        "run_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "environment": "temporary isolated copy of scripts + synthetic local source",
        "source": str(SOURCE.resolve()),
        "network_access": "not used; configured off",
        "checks": checks,
        "passed": sum(item["status"] == "PASS" for item in checks),
        "failed": sum(item["status"] == "FAIL" for item in checks)
    }
    output = BASE / "results" / "verification" / "local_lab.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report["failed"]


if __name__ == "__main__":
    raise SystemExit(main())
