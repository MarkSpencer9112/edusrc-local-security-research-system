// Synthetic sample only: demonstrate an unencoded HTML sink pattern.
function renderMessage(element, userInput) {
  element.innerHTML = userInput;
}
