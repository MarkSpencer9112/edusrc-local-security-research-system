"""Synthetic vulnerable-looking sample for local scanner tests only."""

DEBUG = True


def load_profile(cursor, user_id):
    # Intentionally unsafe construction for static-pattern recognition only.
    cursor.execute("SELECT * FROM profiles WHERE id=" + user_id)
