# EduSRC 本地安全研究系统

本工具用于在本地、默认离线的条件下，对明确授权的源码进行只读启发式审查，并清点依赖清单和配置文件。系统不会执行远程主动测试。机器强制校验的授权来源为 `scope/authorization.json`；`scope/allowed_assets.txt` 是人工查看用的补充清单。两者默认均为空。

## 自然语言控制命令

在工作区根目录下，将用户提出的命令映射到以下操作：

- “开始挖洞” — `python3 EduSRC-Research/scripts/task_controller.py start --source PATH`
- “停止挖洞” — `python3 EduSRC-Research/scripts/task_controller.py stop`
- “继续挖洞” — `python3 EduSRC-Research/scripts/task_controller.py resume`
- “查看进度” — `python3 EduSRC-Research/scripts/task_controller.py status`
- “查看发现” — 检查 `EduSRC-Research/results/findings/` 和 `EduSRC-Research/results/false_positives/`
- “生成报告” — `python3 EduSRC-Research/scripts/report_generator.py`
- “清理任务” — 不提供通用清理命令；只有在检查后，才可删除明确指定的临时测试目录。

默认任务为本地源码审计。程序会拒绝远程任务。启动任务和恢复任务时都会重新校验授权。`agents/` 下的文件是审计角色说明，不是已接入的自主智能体。不要在授权信息、日志或证据中写入秘密。

## 初始化和运行

运行 `python3 EduSRC-Research/scripts/initialize.py` 可创建缺失的状态文件和目录，并检查工作区。已有文件不会被覆盖。初始化程序不会修改全局配置，也不会安装软件包。运行 `python3 EduSRC-Research/scripts/inventory.py PATH` 可清点本地项目；输出为本地 JSON 文件。

授权范围不会由系统推测。开始任务前，请在 `scope/authorization.json` 中填写资产所有者、授权证明编号、UTC 有效期、精确资产、允许活动、禁止事项和限制。若要进行本地源码审计，必须明确授权精确的本地项目路径和 `local_source_audit` 活动。列入远程资产不会启用远程测试。禁止使用通配符。授权过期或格式错误时，系统会拒绝执行。

审计运行器仅使用 Python 标准库、确定性的本地检查和有限时长；不会调用 shell 命令，也不会获取漏洞情报。当前源码检查器通过简单模式匹配标记 SQL 查询构造、动态 HTML 输出、不安全传输设置、疑似凭据字面量和调试开关。清点器仅识别常见依赖清单/锁定文件的名称，不解析版本、不比对漏洞数据库，也不判断依赖是否过期。配置文件会作为普通文本接受上述模式检查，尚无专门的配置规则引擎。所有模式命中都只是需要人工复核的候选项，不代表漏洞可利用的证据。

## 本地合成靶场

运行 `python3 EduSRC-Research/lab/run_lab.py` 可在临时隔离副本中测试任务控制器和本地审计器。靶场只审计随项目提供的合成样例，不启动 Web 服务，也不访问网络；临时授权不会写入正式授权文件。检查摘要保存在 `EduSRC-Research/results/verification/local_lab.json`。样例中故意放置的模式命中仅用于测试检测器，不是实际漏洞报告。

详细的安装、授权、任务控制和报告操作步骤见 [使用教程](EduSRC-Research/TUTORIAL.md)。

## 限制

这是一个基础原型，不是商业 SAST/SCA 引擎。启发式检查可能漏报或误报。当前没有依赖漏洞比对引擎、专用配置审计器或隔离环境动态验证器。如果 Python 操作卡在操作系统调用中，系统无法保证强制终止；当前检查较短、设有时限，并会在阶段之间检查停止请求。暂停采用协作式机制。若任务运行时间较长，请在持久终端会话中启动控制器。系统未实现远程验证、联网更新、自动创建工单或自动提交报告。
