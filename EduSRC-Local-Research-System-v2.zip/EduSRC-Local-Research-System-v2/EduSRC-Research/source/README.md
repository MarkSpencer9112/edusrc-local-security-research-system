# 源码输入

将精确的本地项目目录传给 `task_controller.py start --source`。审计仅读取文件，不会修改源码树。分享输出前，请检查其中是否包含敏感信息。
