#!/usr/bin/env python3
"""Create missing runtime directories/files without overwriting existing content."""
import json
from pathlib import Path
from common import ROOT

DIRS = ["results/inventory", "results/findings", "results/verification", "results/false_positives", "reports/drafts", "reports/final", "evidence/source", "evidence/local_tests", "logs", "state/checkpoints"]
FILES = {"control/task_state.json": {"state": "IDLE", "task_id": None, "task_type": None, "source": None, "stage": "idle", "completed_stages": [], "started_at": None, "updated_at": None, "error": None}, "control/stop.flag": ""}

def main():
    for d in DIRS:
        (ROOT / d).mkdir(parents=True, exist_ok=True)
    for rel, value in FILES.items():
        p = ROOT / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text(json.dumps(value, indent=2) + "\n" if isinstance(value, dict) else value, encoding="utf-8")
    print("Initialized missing local runtime paths; existing files were preserved.")

if __name__ == "__main__": main()
