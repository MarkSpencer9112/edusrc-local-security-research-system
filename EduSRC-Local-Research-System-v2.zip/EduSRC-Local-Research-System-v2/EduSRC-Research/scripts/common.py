"""Shared fail-closed helpers; standard library only."""
import hashlib
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def write_json(path, value):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(str(tmp), str(p))


def log(event, **fields):
    path = ROOT / "logs" / "audit.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    safe = {k: redact(str(v)) for k, v in fields.items()}
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"time": now(), "event": event, **safe}, ensure_ascii=False) + "\n")


def redact(value):
    value = re.sub(r"(?i)(password|passwd|secret|api[_-]?key|token|cookie)(\s*[=:]\s*)[^\s,;]+", r"\1\2[REDACTED]", value)
    return re.sub(r"(?i)bearer\s+[A-Za-z0-9._~+/=-]+", "Bearer [REDACTED]", value)


def validate_authorization(task_type, asset):
    """Require complete current explicit authorization; remote task types always fail closed."""
    if task_type != "local_source_audit":
        return False, "remote or unsupported task type is disabled"
    auth = load_json(ROOT / "scope" / "authorization.json", {})
    required = ("asset_owner", "proof_id", "valid_from_utc", "valid_until_utc")
    if not isinstance(auth, dict) or any(not str(auth.get(k, "")).strip() for k in required):
        return False, "authorization record is incomplete"
    try:
        start = datetime.fromisoformat(auth["valid_from_utc"].replace("Z", "+00:00"))
        end = datetime.fromisoformat(auth["valid_until_utc"].replace("Z", "+00:00"))
        if start.tzinfo is None or end.tzinfo is None:
            return False, "authorization times must include timezone"
        current = datetime.now(timezone.utc)
        if not (start <= current <= end):
            return False, "authorization is not currently valid"
    except (TypeError, ValueError):
        return False, "authorization validity interval is malformed"
    assets = auth.get("assets")
    allowed = auth.get("allowed_activities")
    if not isinstance(assets, list) or not isinstance(allowed, list):
        return False, "assets and activities must be explicit lists"
    if not assets or not allowed or "local_source_audit" not in allowed:
        return False, "no explicit local source audit scope"
    if any(not isinstance(x, str) or not x.strip() or any(c in x for c in "*?[]") for x in assets):
        return False, "wildcards or invalid asset entries are prohibited"
    exact = str(Path(asset).resolve())
    if exact not in [str(Path(x).resolve()) for x in assets]:
        return False, "source path is not explicitly authorized"
    if not Path(exact).is_dir():
        return False, "authorized source directory is unavailable"
    return True, "authorized"


def source_digest(source):
    h = hashlib.sha256()
    for p in sorted(Path(source).rglob("*")):
        if not p.is_file() or any(part in {".git", "node_modules", ".venv", "venv"} for part in p.parts):
            continue
        try:
            h.update(str(p.relative_to(source)).encode())
            h.update(p.read_bytes())
        except OSError:
            continue
    return h.hexdigest()


def stopped():
    return (ROOT / "control" / "stop.flag").exists()
