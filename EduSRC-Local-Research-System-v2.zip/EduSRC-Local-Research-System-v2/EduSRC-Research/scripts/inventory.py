#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from common import ROOT

IGNORE = {".git", "node_modules", "vendor", ".venv", "venv", "__pycache__"}
MARKERS = {"pyproject.toml", "requirements.txt", "Pipfile", "poetry.lock", "package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "go.mod", "Cargo.toml", "Gemfile", "composer.json", "Dockerfile", "docker-compose.yml", ".env.example"}

def inventory(source):
    source = Path(source).resolve()
    if not source.is_dir(): raise ValueError("source must be a local directory")
    files, manifests = [], []
    for p in source.rglob("*"):
        if any(part in IGNORE for part in p.relative_to(source).parts): continue
        if p.is_file():
            rel = str(p.relative_to(source))
            files.append(rel)
            if p.name in MARKERS: manifests.append(rel)
    return {"source": str(source), "file_count": len(files), "files": sorted(files), "dependency_and_config_markers": sorted(manifests)}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("source"); args = ap.parse_args()
    result = inventory(args.source)
    out = ROOT / "results" / "inventory" / (Path(args.source).resolve().name + ".json")
    out.parent.mkdir(parents=True, exist_ok=True); out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"file_count": result["file_count"], "markers": result["dependency_and_config_markers"], "output": str(out)}, indent=2))
if __name__ == "__main__": main()
