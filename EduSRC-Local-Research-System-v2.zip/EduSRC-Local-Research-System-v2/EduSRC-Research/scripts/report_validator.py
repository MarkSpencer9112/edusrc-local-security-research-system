#!/usr/bin/env python3
import json
import sys
from pathlib import Path

REQUIRED = {"finding_id", "title", "type", "file", "line", "cause", "trigger_condition", "impact", "verification_method", "verification_status", "evidence", "confidence", "recommendation"}

def validate(data):
    errors = []
    findings = data.get("findings", [])
    ids = set()
    for i, item in enumerate(findings):
        missing = REQUIRED - set(item)
        if missing: errors.append("finding %d missing %s" % (i, ",".join(sorted(missing))))
        if item.get("finding_id") in ids: errors.append("duplicate finding id " + str(item.get("finding_id")))
        ids.add(item.get("finding_id"))
        if item.get("verification_status") == "CONFIRMED" and not item.get("verification_evidence"):
            errors.append("confirmed finding lacks local verification evidence: " + str(item.get("finding_id")))
    return errors

def main():
    p = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    if not p or not p.exists(): print("usage: report_validator.py FINDINGS.json", file=sys.stderr); sys.exit(2)
    data = json.loads(p.read_text(encoding="utf-8")); errors = validate(data)
    print(json.dumps({"valid": not errors, "finding_count": len(data.get("findings", [])), "errors": errors}, indent=2)); sys.exit(1 if errors else 0)
if __name__ == "__main__": main()
