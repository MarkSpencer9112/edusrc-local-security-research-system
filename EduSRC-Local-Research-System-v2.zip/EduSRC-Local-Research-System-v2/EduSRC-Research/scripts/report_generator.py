#!/usr/bin/env python3
import json
from datetime import datetime, timezone
from pathlib import Path
from common import ROOT, redact
from report_validator import validate

def generate():
    rows = []
    for p in sorted((ROOT / "results" / "findings").glob("*.json")):
        try: data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError): continue
        errors = validate(data)
        rows.append((p, data, errors))
    out = ROOT / "reports" / "drafts" / "security_audit.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    text = ["# Local Security Audit Report", "", "Generated: " + datetime.now(timezone.utc).isoformat(timespec="seconds"), "", "Scope: local source review only. Heuristic candidates are not confirmed vulnerabilities.", "", "## Findings", ""]
    if not rows: text.append("No findings result files were available.")
    for p, data, errors in rows:
        text += ["### Task " + redact(str(data.get("task_id", p.stem))), "", "Source: `" + redact(str(data.get("source", "unknown"))) + "`", "", "Validator: " + ("PASS" if not errors else "FAIL — " + "; ".join(errors)), ""]
        if not data.get("findings"): text += ["No candidate findings.", ""]
        for f in data.get("findings", []):
            text += ["#### " + redact(str(f.get("title", "Untitled"))), "", "- ID: " + redact(str(f.get("finding_id", ""))), "- Type: " + redact(str(f.get("type", ""))), "- Location: `" + redact(str(f.get("file", ""))) + ":" + str(f.get("line", "?")) + "`", "- Status: " + str(f.get("verification_status", "UNVERIFIED")), "- Severity: " + str(f.get("severity", "unrated")), "- Confidence: " + str(f.get("confidence", "unknown")), "- Cause: " + redact(str(f.get("cause", ""))), "- Trigger: " + redact(str(f.get("trigger_condition", ""))), "- Impact: " + redact(str(f.get("impact", ""))), "- Evidence: " + redact(str(f.get("evidence", ""))), "- Recommendation: " + redact(str(f.get("recommendation", ""))), ""]
    out.write_text("\n".join(text) + "\n", encoding="utf-8")
    return out

if __name__ == "__main__": print(generate())
