#!/usr/bin/env python3
"""Bounded, read-only local heuristic auditor."""
import json
import re
import sys
import time
import uuid
from pathlib import Path
from common import ROOT, log, now, stopped, validate_authorization, source_digest, write_json
from inventory import inventory

MAX_BYTES = 2_000_000
EXCLUDE = {".git", "node_modules", "vendor", ".venv", "venv", "__pycache__"}
PATTERNS = [
    ("SQL construction", re.compile(r"(?i)(execute|query)\s*\([^\n]*(%s|\+\s*\w+|\.format\(|f['\"])"), "Review whether untrusted input reaches a SQL query without parameterization."),
    ("Dynamic HTML output", re.compile(r"(?i)(innerHTML\s*=|dangerouslySetInnerHTML|mark_safe\s*\()"), "Review whether untrusted content is safely encoded before HTML output."),
    ("Weak transport or TLS setting", re.compile(r"(?i)(verify\s*=\s*False|CERT_NONE|http://)"), "Review whether transport security is intentionally disabled."),
    ("Potential secret literal", re.compile(r"(?i)(password|api[_-]?key|secret|token)\s*[:=]\s*['\"][^'\"]{6,}"), "Review for hard-coded credentials; candidate value is intentionally omitted."),
    ("Debug configuration", re.compile(r"(?i)(DEBUG\s*=\s*True|debug\s*:\s*true)"), "Review whether debug mode is enabled outside local development."),
]

def scan(source, deadline, task_id):
    findings = []
    for p in Path(source).rglob("*"):
        if stopped(): break
        pause = ROOT / "control" / "pause.flag"
        while pause.exists() and not stopped():
            state_path = ROOT / "control" / "task_state.json"
            state = __import__("common").load_json(state_path, {})
            if state.get("state") == "PAUSE_REQUESTED":
                state["state"] = "PAUSED"; state["stage"] = "local_audit"; state["updated_at"] = now(); write_json(state_path, state)
                write_json(ROOT / "state" / "checkpoints" / (task_id + ".json"), {"task_id": task_id, "source": str(source), "stage": "local_audit", "status": "PAUSED"})
            time.sleep(0.25)
        if not p.is_file() or any(x in EXCLUDE for x in p.parts): continue
        try:
            if p.stat().st_size > MAX_BYTES or time.monotonic() > deadline: continue
            lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError: continue
        for n, line in enumerate(lines, 1):
            for title, pattern, advice in PATTERNS:
                if pattern.search(line):
                    findings.append({"finding_id": "F-" + uuid.uuid4().hex[:10], "title": title, "type": title, "file": str(p.relative_to(source)), "line": n, "function": "not inferred", "cause": advice, "trigger_condition": "Requires manual data-flow/context review", "impact": "Undetermined; heuristic candidate only", "verification_method": "Static pattern match", "verification_status": "UNVERIFIED", "evidence": "Line content withheld from output to reduce secret leakage; inspect source locally.", "confidence": "low", "severity": "informational", "recommendation": advice})
    return findings

def run(source, task_id=None, timeout=120):
    source = str(Path(source).resolve())
    ok, reason = validate_authorization("local_source_audit", source)
    if not ok: raise PermissionError(reason)
    task_id = task_id or ("TASK-" + uuid.uuid4().hex[:12])
    started = now(); digest = source_digest(source); deadline = time.monotonic() + timeout
    write_json(ROOT / "state" / "checkpoints" / (task_id + ".json"), {"task_id": task_id, "source": source, "source_digest": digest, "stage": "source", "started_at": started, "status": "RUNNING"})
    log("audit_started", task_id=task_id, source=source, task_type="local_source_audit")
    inv = inventory(source)
    findings = scan(source, deadline, task_id)
    out = ROOT / "results" / "findings" / (task_id + ".json")
    write_json(out, {"task_id": task_id, "source": source, "source_digest": digest, "findings": findings, "completed_at": now(), "stopped": stopped()})
    write_json(ROOT / "results" / "inventory" / (task_id + ".json"), inv)
    log("audit_completed", task_id=task_id, finding_count=len(findings), output=out)
    return {"task_id": task_id, "finding_count": len(findings), "output": str(out)}

if __name__ == "__main__":
    try: print(json.dumps(run(sys.argv[1])))
    except Exception as exc:
        log("audit_error", error=exc); print("ERROR: " + str(exc), file=sys.stderr); sys.exit(2)
