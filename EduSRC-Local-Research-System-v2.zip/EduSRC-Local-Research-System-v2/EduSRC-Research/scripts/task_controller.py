#!/usr/bin/env python3
"""Single-process cooperative task controller; stop flag checked at stage boundaries."""
import argparse
import json
import os
import sys
import time
import uuid
from pathlib import Path
from common import ROOT, load_json, log, now, validate_authorization, write_json

STATE = ROOT / "control" / "task_state.json"
FLAG = ROOT / "control" / "stop.flag"
PAUSE = ROOT / "control" / "pause.flag"

def save(state): state["updated_at"] = now(); write_json(STATE, state)
def get(): return load_json(STATE, {"state": "IDLE", "completed_stages": []})

def command(args):
    s = get()
    if args.action == "status": print(json.dumps(s, indent=2)); return 0
    if args.action == "stop":
        if s.get("state") not in ("RUNNING", "PAUSE_REQUESTED", "INITIALIZING"):
            print(json.dumps(s, indent=2)); return 0
        s["state"] = "STOPPING"; save(s); FLAG.write_text("stop requested " + now(), encoding="utf-8"); log("stop_requested", task_id=s.get("task_id")); print("Stop requested; cooperative checkpointing applies."); return 0
    if args.action == "pause":
        if s.get("state") != "RUNNING": print("No running task to pause."); return 0
        s["state"] = "PAUSE_REQUESTED"; save(s); PAUSE.write_text("pause requested " + now(), encoding="utf-8"); return 0
    if args.action == "start":
        if s.get("state") in ("RUNNING", "INITIALIZING", "PAUSE_REQUESTED", "STOPPING"):
            print("A task is already active; refusing duplicate start.", file=sys.stderr); return 2
        source = str(Path(args.source).resolve())
        ok, reason = validate_authorization(args.task_type, source)
        if not ok: print("Authorization denied: " + reason, file=sys.stderr); return 3
        FLAG.unlink(missing_ok=True); PAUSE.unlink(missing_ok=True)
        s = {"state": "INITIALIZING", "task_id": "TASK-" + uuid.uuid4().hex[:12], "task_type": args.task_type, "source": source, "stage": "initializing", "completed_stages": [], "started_at": now(), "updated_at": now(), "error": None}
        save(s); log("task_started", task_id=s["task_id"], source=source, command="start")
        return run(s, args.timeout)
    if args.action == "resume":
        if s.get("state") not in ("PAUSED", "STOPPED", "ERROR"):
            print("No resumable task.", file=sys.stderr); return 2
        ok, reason = validate_authorization(s.get("task_type"), s.get("source"))
        if not ok: print("Resume denied: " + reason, file=sys.stderr); return 3
        cp = load_json(ROOT / "state" / "checkpoints" / (s["task_id"] + ".json"), {})
        if cp.get("source_digest") and cp["source_digest"] != __import__("common").source_digest(s["source"]):
            print("Resume denied: source changed since checkpoint.", file=sys.stderr); return 3
        FLAG.unlink(missing_ok=True); PAUSE.unlink(missing_ok=True); s["state"] = "RUNNING"; save(s); return run(s, args.timeout)
    return 2

def run(s, timeout):
    from audit_runner import run as audit
    try:
        # Revalidate immediately before the audit stage.
        ok, reason = validate_authorization(s["task_type"], s["source"])
        if not ok: raise PermissionError(reason)
        if FLAG.exists(): s["state"] = "STOPPED"; save(s); return 0
        s["state"] = "RUNNING"; s["stage"] = "local_audit"; save(s)
        audit(s["source"], s["task_id"], timeout)
        s["completed_stages"] = ["local_audit"]; s["state"] = "STOPPED" if FLAG.exists() else "COMPLETED"; s["stage"] = "finished"; s["ended_at"] = now(); save(s)
        log("task_ended", task_id=s["task_id"], state=s["state"]); return 0
    except Exception as exc:
        s["state"] = "ERROR"; s["error"] = str(exc); s["ended_at"] = now(); save(s); log("task_error", task_id=s.get("task_id"), error=exc); print(str(exc), file=sys.stderr); return 1

def main():
    p = argparse.ArgumentParser(); p.add_argument("action", choices=["start", "stop", "pause", "resume", "status"]); p.add_argument("--source"); p.add_argument("--task-type", default="local_source_audit"); p.add_argument("--timeout", type=int, default=120); a = p.parse_args()
    if a.action == "start" and not a.source: p.error("start requires --source")
    sys.exit(command(a))
if __name__ == "__main__": main()
